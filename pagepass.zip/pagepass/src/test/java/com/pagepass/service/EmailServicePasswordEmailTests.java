package com.pagepass.service;

import com.pagepass.entity.User;
import org.junit.jupiter.api.Test;
import org.springframework.mail.MailSendException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

class EmailServicePasswordEmailTests {

    @Test
    void sendsExistingCredentialsToRegisteredEmail() {
        JavaMailSender mailSender = mock(JavaMailSender.class);
        EmailService emailService = new EmailService(mailSender);
        ReflectionTestUtils.setField(emailService, "mailUsername", "sender@example.com");
        User user = new User("PagePass Reader", "reader@example.com", null, "password123");

        emailService.sendPasswordEmail(user);

        org.mockito.ArgumentCaptor<SimpleMailMessage> messageCaptor =
                org.mockito.ArgumentCaptor.forClass(SimpleMailMessage.class);
        verify(mailSender).send(messageCaptor.capture());
        SimpleMailMessage message = messageCaptor.getValue();
        assertEquals("reader@example.com", message.getTo()[0]);
        assertEquals("sender@example.com", message.getFrom());
        assertEquals("PagePass | Password Recovery", message.getSubject());
        org.junit.jupiter.api.Assertions.assertTrue(
                message.getText().contains("Username: PagePass Reader"));
        org.junit.jupiter.api.Assertions.assertTrue(
                message.getText().contains("Password: password123"));
    }

    @Test
    void propagatesMailDeliveryFailure() {
        JavaMailSender mailSender = mock(JavaMailSender.class);
        EmailService emailService = new EmailService(mailSender);
        User user = new User("PagePass Reader", "reader@example.com", null, "password123");
        doThrow(new MailSendException("SMTP failure"))
                .when(mailSender)
                .send(any(SimpleMailMessage.class));

        assertThrows(
                MailSendException.class,
                () -> emailService.sendPasswordEmail(user)
        );
    }
}
