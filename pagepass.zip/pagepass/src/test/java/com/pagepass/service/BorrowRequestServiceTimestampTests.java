package com.pagepass.service;

import com.pagepass.entity.Book;
import com.pagepass.entity.BorrowRequest;
import com.pagepass.repository.BookRepository;
import com.pagepass.repository.BorrowRequestRepository;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class BorrowRequestServiceTimestampTests {

    @Test
    void recordsEachTimestampAcrossRequestLifecycle() {
        BorrowRequestRepository requestRepository =
                mock(BorrowRequestRepository.class);
        BookRepository bookRepository = mock(BookRepository.class);
        EmailService emailService = mock(EmailService.class);
        NotificationService notificationService =
                mock(NotificationService.class);
        BorrowRequestService service = new BorrowRequestService(
                requestRepository,
                bookRepository,
                emailService,
                notificationService
        );
        Book book = mock(Book.class);

        when(book.getId()).thenReturn(7L);
        when(book.getTitle()).thenReturn("PagePass Test Book");
        when(book.getOwnerEmail()).thenReturn("owner@example.com");
        when(book.getStatus()).thenReturn("Available");
        when(bookRepository.findById(7L)).thenReturn(Optional.of(book));
        when(requestRepository.save(any(BorrowRequest.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));
        when(requestRepository.findByOwnerEmailAndBookIdAndStatusIgnoreCase(
                "owner@example.com",
                7L,
                BorrowRequest.STATUS_PENDING
        )).thenReturn(List.of());

        LocalDateTime beforeRequest = LocalDateTime.now().minusSeconds(1);
        BorrowRequest request = service.createRequest(
                7L,
                "receiver@example.com",
                "PagePass Receiver",
                "5550100",
                "Test address",
                "Free",
                null,
                null
        );
        LocalDateTime afterRequest = LocalDateTime.now().plusSeconds(1);

        assertNotNull(request);
        request.setId(42L);
        assertTrue(request.getRequestDate().isAfter(beforeRequest));
        assertTrue(request.getRequestDate().isBefore(afterRequest));

        when(requestRepository.findById(42L)).thenReturn(Optional.of(request));
        LocalDateTime beforeApproval = LocalDateTime.now().minusSeconds(1);
        assertNotNull(service.approveRequest(42L));
        LocalDateTime afterApproval = LocalDateTime.now().plusSeconds(1);
        assertTrue(request.getApprovedDate().isAfter(beforeApproval));
        assertTrue(request.getApprovedDate().isBefore(afterApproval));

        LocalDateTime beforeShipping = LocalDateTime.now().minusSeconds(1);
        assertNotNull(service.shipBook(42L));
        LocalDateTime afterShipping = LocalDateTime.now().plusSeconds(1);
        assertTrue(request.getShippedDate().isAfter(beforeShipping));
        assertTrue(request.getShippedDate().isBefore(afterShipping));

        reset(requestRepository);
        when(requestRepository.findById(42L)).thenReturn(Optional.of(request));
        when(requestRepository.save(any(BorrowRequest.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        LocalDateTime beforeReceipt = LocalDateTime.now().minusSeconds(1);
        assertNotNull(service.confirmReceived(42L));
        LocalDateTime afterReceipt = LocalDateTime.now().plusSeconds(1);
        assertTrue(request.getReceivedDate().isAfter(beforeReceipt));
        assertTrue(request.getReceivedDate().isBefore(afterReceipt));
        assertEquals(BorrowRequest.STATUS_DELIVERED, request.getStatus());
        verify(requestRepository).save(request);
    }

    @Test
    void confirmsReceiptForEveryTransactionTypeAndPreservesPaymentDetails() {
        BorrowRequestRepository requestRepository =
                mock(BorrowRequestRepository.class);
        BookRepository bookRepository = mock(BookRepository.class);
        EmailService emailService = mock(EmailService.class);
        NotificationService notificationService =
                mock(NotificationService.class);
        BorrowRequestService service = new BorrowRequestService(
                requestRepository,
                bookRepository,
                emailService,
                notificationService
        );

        when(bookRepository.findById(any())).thenReturn(Optional.empty());
        when(requestRepository.save(any(BorrowRequest.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        List<String> transactionTypes =
                List.of("Donate", "Sell", "Exchange", "Borrow");

        for (int index = 0; index < transactionTypes.size(); index++) {
            long requestId = index + 1L;
            BorrowRequest request = new BorrowRequest();
            request.setId(requestId);
            request.setBookId(10L);
            request.setBookTitle("Test title");
            request.setOwnerEmail("owner@example.com");
            request.setRequesterEmail("requester@example.com");
            request.setActionType(transactionTypes.get(index));
            request.setStatus(BorrowRequest.STATUS_SHIPPED);
            request.setOfferedBook("Offered title");
            request.setBorrowDuration(14);

            if ("Sell".equals(request.getActionType())) {
                request.setSellingPrice(new BigDecimal("19.95"));
                request.setPaymentStatus("Paid");
                request.setPaymentTransactionId("pay_test_123");
                request.setPaymentDate(
                        LocalDateTime.of(2026, 10, 14, 9, 0)
                );
            }

            when(requestRepository.findById(requestId))
                    .thenReturn(Optional.of(request));

            BorrowRequest delivered = service.confirmReceived(requestId);

            assertNotNull(delivered);
            assertEquals(BorrowRequest.STATUS_DELIVERED, delivered.getStatus());
            assertEquals(transactionTypes.get(index), delivered.getActionType());
            assertEquals("Test title", delivered.getBookTitle());
            assertEquals("owner@example.com", delivered.getOwnerEmail());
            assertEquals("requester@example.com", delivered.getRequesterEmail());
            assertEquals("Offered title", delivered.getOfferedBook());
            assertEquals(14, delivered.getBorrowDuration());

            if ("Sell".equals(delivered.getActionType())) {
                assertEquals(new BigDecimal("19.95"), delivered.getSellingPrice());
                assertEquals("Paid", delivered.getPaymentStatus());
                assertEquals("pay_test_123", delivered.getPaymentTransactionId());
                assertEquals(
                        LocalDateTime.of(2026, 10, 14, 9, 0),
                        delivered.getPaymentDate()
                );
            }
        }

        verify(requestRepository, org.mockito.Mockito.times(4))
                .save(any(BorrowRequest.class));
    }
}
