package com.pagepass.service;

import com.pagepass.entity.User;
import com.pagepass.repository.UserRepository;
import org.junit.jupiter.api.Test;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class UserServiceForgotPasswordTests {

    @Test
    void sendsCredentialsForMatchingRegisteredEmail() {
        UserRepository userRepository = mock(UserRepository.class);
        EmailService emailService = mock(EmailService.class);
        UserService userService = new UserService(userRepository, emailService);
        User user = new User("PagePass Reader", "reader@example.com", null, "password123");
        when(userRepository.findByEmail("reader@example.com"))
                .thenReturn(Optional.of(user));

        assertTrue(userService.sendPasswordEmail("reader@example.com"));

        verify(emailService).sendPasswordEmail(user);
    }

    @Test
    void doesNotSendWhenEmailIsNotRegistered() {
        UserRepository userRepository = mock(UserRepository.class);
        EmailService emailService = mock(EmailService.class);
        UserService userService = new UserService(userRepository, emailService);
        when(userRepository.findByEmail("unknown@example.com"))
                .thenReturn(Optional.empty());

        assertFalse(userService.sendPasswordEmail("unknown@example.com"));

        verify(emailService, never()).sendPasswordEmail(org.mockito.ArgumentMatchers.any());
    }
}
