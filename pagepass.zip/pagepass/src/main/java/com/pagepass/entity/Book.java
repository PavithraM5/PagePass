package com.pagepass.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "books")
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String title;

    @Column(nullable = false)
    private String author;

    private String isbn;

    private String category;

    private String genre;

    @Column(length = 1000)
    private String description;

    private String actionType;

    private String ownerEmail;

    private String status = "Available";

    private String borrowedBy;

    // Book cover image stored as Base64
    @Lob
    @Column(columnDefinition = "LONGTEXT")
    private String imageUrl;


    // =========================================================
    // SELLING PRICE
    // =========================================================

    @Column(precision = 10, scale = 2)
    private BigDecimal sellingPrice;


    // =========================================================
    // MAXIMUM BORROW DURATION
    // Owner decides how many days the book can be borrowed
    // =========================================================

    private Integer maxBorrowDuration;


    // =========================================================
    // DEFAULT CONSTRUCTOR
    // =========================================================

    public Book() {
    }


    // =========================================================
    // CONSTRUCTOR
    // =========================================================

    public Book(
            String title,
            String author,
            String isbn,
            String category,
            String genre,
            String description,
            String actionType,
            String ownerEmail) {

        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.category = category;
        this.genre = genre;
        this.description = description;
        this.actionType = actionType;
        this.ownerEmail = ownerEmail;
        this.status = "Available";
    }


    // =========================================================
    // ID
    // =========================================================

    public Long getId() {
        return id;
    }


    // =========================================================
    // TITLE
    // =========================================================

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }


    // =========================================================
    // AUTHOR
    // =========================================================

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }


    // =========================================================
    // ISBN
    // =========================================================

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }


    // =========================================================
    // CATEGORY
    // =========================================================

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }


    // =========================================================
    // GENRE
    // =========================================================

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }


    // =========================================================
    // DESCRIPTION
    // =========================================================

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }


    // =========================================================
    // ACTION TYPE
    // =========================================================

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }


    // =========================================================
    // OWNER EMAIL
    // =========================================================

    public String getOwnerEmail() {
        return ownerEmail;
    }

    public void setOwnerEmail(String ownerEmail) {
        this.ownerEmail = ownerEmail;
    }


    // =========================================================
    // STATUS
    // =========================================================

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


    // =========================================================
    // BORROWED BY
    // =========================================================

    public String getBorrowedBy() {
        return borrowedBy;
    }

    public void setBorrowedBy(String borrowedBy) {
        this.borrowedBy = borrowedBy;
    }


    // =========================================================
    // IMAGE URL
    // =========================================================

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }


    // =========================================================
    // SELLING PRICE
    // =========================================================

    public BigDecimal getSellingPrice() {
        return sellingPrice;
    }

    public void setSellingPrice(BigDecimal sellingPrice) {
        this.sellingPrice = sellingPrice;
    }


    // =========================================================
    // MAX BORROW DURATION
    // =========================================================

    public Integer getMaxBorrowDuration() {
        return maxBorrowDuration;
    }

    public void setMaxBorrowDuration(Integer maxBorrowDuration) {
        this.maxBorrowDuration = maxBorrowDuration;
    }

}