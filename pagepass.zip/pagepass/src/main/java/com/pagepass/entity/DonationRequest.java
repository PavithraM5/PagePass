package com.pagepass.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "donation_requests")
public class DonationRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long bookId;

    private String bookTitle;

    private String donorEmail;

    private String requesterEmail;

    private String status = "Pending";

    public DonationRequest() {
    }

    public DonationRequest(Long bookId,
                           String bookTitle,
                           String donorEmail,
                           String requesterEmail) {

        this.bookId = bookId;
        this.bookTitle = bookTitle;
        this.donorEmail = donorEmail;
        this.requesterEmail = requesterEmail;
        this.status = "Pending";
    }

    public Long getId() {
        return id;
    }

    public Long getBookId() {
        return bookId;
    }

    public void setBookId(Long bookId) {
        this.bookId = bookId;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public String getDonorEmail() {
        return donorEmail;
    }

    public void setDonorEmail(String donorEmail) {
        this.donorEmail = donorEmail;
    }

    public String getRequesterEmail() {
        return requesterEmail;
    }

    public void setRequesterEmail(String requesterEmail) {
        this.requesterEmail = requesterEmail;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}