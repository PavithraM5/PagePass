package com.pagepass.service;

import com.pagepass.entity.User;
import com.pagepass.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final EmailService emailService;

    public UserService(UserRepository userRepository, EmailService emailService) {
        this.userRepository = userRepository;
        this.emailService = emailService;
    }

    public User registerUser(User user) {
        return userRepository.save(user);
    }

    public User loginUser(String email, String password) {
        return userRepository
                .findByEmailAndPassword(email, password)
                .orElse(null);
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public User getUserByEmail(String email) {
        return userRepository
                .findByEmail(email)
                .orElse(null);
    }

    public boolean sendPasswordEmail(String email) {
        User user = getUserByEmail(email);

        if (user == null) {
            return false;
        }

        emailService.sendPasswordEmail(user);
        return true;
    }

    public User updateUser(User user) {

        User existingUser = userRepository
                .findByEmail(user.getEmail())
                .orElse(null);

        if (existingUser == null) {
            return null;
        }

        existingUser.setName(user.getName());
        existingUser.setPhone(user.getPhone());
        existingUser.setLocation(user.getLocation());

        return userRepository.save(existingUser);
    }
}