package com.pagepass.service;

import com.pagepass.entity.Book;
import com.pagepass.repository.BookRepository;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

    private final BookRepository bookRepository;

    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // =========================================================
    // ADD BOOK
    // =========================================================
    public Book addBook(Book book) {

        if (book.getStatus() == null ||
                book.getStatus().trim().isEmpty()) {

            book.setStatus("Available");
        }

        return bookRepository.save(book);
    }

    // =========================================================
    // GET ALL AVAILABLE BOOKS
    // =========================================================
    public List<Book> getAllBooks() {

        return bookRepository.findByStatusIgnoreCase("Available");
    }

    // =========================================================
    // GET BOOKS BY ACTION
    // =========================================================
    public List<Book> getBooksByAction(String actionType) {

        return bookRepository.findByActionTypeAndStatusIgnoreCase(
                actionType,
                "Available"
        );
    }

    // =========================================================
    // GET MY LISTED BOOKS
    // =========================================================
    public List<Book> getBooksByOwner(String email) {

        return bookRepository.findByOwnerEmail(email)
                .stream()
                .filter(book -> book.getStatus() == null ||
                        !"Completed".equalsIgnoreCase(book.getStatus()))
                .toList();
    }

    // =========================================================
    // GET MY BOOKS
    // =========================================================
    public List<Book> getMyBooks(String email) {

        return bookRepository.findByBorrowedBy(email);
    }

    // =========================================================
    // GET BOOK BY ID
    // =========================================================
    public Book getBookById(Long id) {

        return bookRepository.findById(id).orElse(null);
    }

    // =========================================================
    // BORROW BOOK
    // =========================================================
    public Book borrowBook(Long id, String email) {

        Book book = bookRepository.findById(id).orElse(null);

        if (book == null) {
            return null;
        }

        if (!"Available".equalsIgnoreCase(book.getStatus())) {
            return null;
        }

        if (book.getActionType() == null ||
                !"Borrow".equalsIgnoreCase(book.getActionType())) {

            return null;
        }

        book.setStatus("Borrowed");
        book.setBorrowedBy(email);

        return bookRepository.save(book);
    }

    // =========================================================
    // MARK BOOK UNAVAILABLE
    // =========================================================
    public Book markUnavailable(Long id) {

        Book book = bookRepository.findById(id).orElse(null);

        if (book == null) {
            return null;
        }

        book.setStatus("Unavailable");

        return bookRepository.save(book);
    }

    // =========================================================
    // DELETE BOOK
    // =========================================================
    public boolean deleteBook(Long id) {

        Book book = bookRepository.findById(id).orElse(null);

        if (book == null) {
            return false;
        }

        if (!"Available".equalsIgnoreCase(book.getStatus())) {
            return false;
        }

        bookRepository.delete(book);

        return true;
    }
}