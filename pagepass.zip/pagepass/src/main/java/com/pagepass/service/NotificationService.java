package com.pagepass.service;

import com.pagepass.entity.Notification;
import com.pagepass.repository.NotificationRepository;
import org.springframework.stereotype.Service;
import org.springframework.scheduling.annotation.Async;

import java.util.List;

@Service
public class NotificationService {

    private final NotificationRepository notificationRepository;

    public NotificationService(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

    @Async
    public void createNotification(
            String email,
            String message,
            String type) {

        createNotification(email, message, type, null);
    }

    @Async
    public void createNotification(
            String email,
            String message,
            String type,
            Long relatedRequestId) {

        Notification notification =
                new Notification(email, message, type);

        notification.setRelatedRequestId(relatedRequestId);
        notificationRepository.save(notification);
    }

    public List<Notification> getNotifications(String email) {
        return notificationRepository
                .findByRecipientEmailOrderByIdDesc(email);
    }

    public long getUnreadCount(String email) {
        return notificationRepository
                .countByRecipientEmailAndIsReadFalse(email);
    }

    public Notification markAsRead(Long id) {

        Notification notification =
                notificationRepository.findById(id).orElse(null);

        if (notification == null) {
            return null;
        }

        notification.setRead(true);

        return notificationRepository.save(notification);
    }

    public void markAllAsRead(String email) {

        List<Notification> notifications =
                notificationRepository
                        .findByRecipientEmailOrderByIdDesc(email);

        for (Notification notification : notifications) {
            notification.setRead(true);
        }

        notificationRepository.saveAll(notifications);
    }
}