package com.pagepass.service;

import com.pagepass.entity.Book;
import com.pagepass.entity.BorrowRequest;
import com.pagepass.repository.BookRepository;
import com.pagepass.repository.BorrowRequestRepository;

import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class BorrowRequestService {

    private final BorrowRequestRepository requestRepository;
    private final BookRepository bookRepository;
    private final EmailService emailService;
    private final NotificationService notificationService;

    public BorrowRequestService(
            BorrowRequestRepository requestRepository,
            BookRepository bookRepository,
            EmailService emailService,
            NotificationService notificationService) {

        this.requestRepository = requestRepository;
        this.bookRepository = bookRepository;
        this.emailService = emailService;
        this.notificationService = notificationService;
    }

    // =========================================================
    // CREATE REQUEST
    // =========================================================

    public BorrowRequest createRequest(
            Long bookId,
            String email,
            String name,
            String phone,
            String address,
            String actionType,
            String offeredBook,
            Integer borrowDuration) {

        Book book = bookRepository.findById(bookId)
                .orElse(null);

        if (book == null) {
            return null;
        }

        if (book.getStatus() == null ||
                !book.getStatus().equalsIgnoreCase("Available")) {
            return null;
        }

        if (book.getOwnerEmail() != null &&
                book.getOwnerEmail().equalsIgnoreCase(email)) {
            return null;
        }

        if (!isValidAction(actionType)) {
            return null;
        }

        BorrowRequest request = new BorrowRequest();

        request.setBookId(book.getId());
        request.setBookTitle(book.getTitle());
        request.setOwnerEmail(book.getOwnerEmail());

        request.setRequesterEmail(email);
        request.setRequesterName(name);
        request.setPhone(phone);
        request.setAddress(address);

        request.setActionType(actionType);
        request.setOfferedBook(offeredBook);
        request.setStatus("Pending");
        request.setRequestDate(LocalDateTime.now());

        // =====================================================
        // BORROW DETAILS
        // =====================================================

        if ("Borrow".equalsIgnoreCase(actionType)) {

            if (borrowDuration == null || borrowDuration <= 0) {
                return null;
            }

            if (book.getMaxBorrowDuration() == null ||
                    borrowDuration > book.getMaxBorrowDuration()) {
                return null;
            }

            request.setBorrowDuration(borrowDuration);
        }

        // =====================================================
        // SELL DETAILS
        // =====================================================

        if ("Sell".equalsIgnoreCase(actionType)) {

            if (book.getSellingPrice() == null ||
                    book.getSellingPrice()
                            .compareTo(BigDecimal.ZERO) <= 0) {
                return null;
            }

            request.setSellingPrice(book.getSellingPrice());
            request.setPaymentStatus("Pending");
        }

        BorrowRequest savedRequest =
                requestRepository.save(request);

        // Email to owner
        emailService.sendNewRequestEmail(savedRequest);

        // Notification to owner
        notificationService.createNotification(
                savedRequest.getOwnerEmail(),

                "New "
                        + savedRequest.getActionType()
                        + " request received for your book: \""
                        + savedRequest.getBookTitle()
                        + "\".",

                "NEW_REQUEST"
                ,
                savedRequest.getId()
        );

        return savedRequest;
    }

    // =========================================================
    // OWNER - VIEW REQUESTS
    // =========================================================

    public List<BorrowRequest> getOwnerRequests(
            String ownerEmail) {

        return requestRepository.findByOwnerEmail(ownerEmail);
    }

    // =========================================================
    // USER - VIEW MY REQUESTS
    // =========================================================

    public List<BorrowRequest> getMyRequests(
            String email) {

        return requestRepository.findByRequesterEmail(email);
    }

    // =========================================================
    // USER - VIEW HISTORY
    // =========================================================

    public List<BorrowRequest> getMyHistory(
            String email) {

        return requestRepository
                .findByRequesterEmailAndStatusIn(
                        email,
                        List.of(
                                BorrowRequest.STATUS_COMPLETED,
                                BorrowRequest.STATUS_DELIVERED
                        )
                );
    }

    // =========================================================
    // OWNER - VIEW HISTORY
    // =========================================================

    public List<BorrowRequest> getOwnerHistory(
            String email) {

        return requestRepository
                .findByOwnerEmailAndStatusIn(
                        email,
                        List.of(
                                BorrowRequest.STATUS_COMPLETED,
                                BorrowRequest.STATUS_DELIVERED
                        )
                );
    }

    // =========================================================
    // APPROVE REQUEST
    // =========================================================

    public BorrowRequest approveRequest(
            Long requestId) {

        BorrowRequest request =
                requestRepository.findById(requestId)
                        .orElse(null);

        if (request == null) {
            return null;
        }

        if (!"Pending".equalsIgnoreCase(request.getStatus())) {
            return request;
        }

        Book book =
                bookRepository.findById(request.getBookId())
                        .orElse(null);

        if (book == null) {
            return null;
        }

        if (book.getStatus() == null ||
                !book.getStatus().equalsIgnoreCase("Available")) {
            return null;
        }

        // =====================================================
        // BORROW
        // =====================================================

        if ("Borrow".equalsIgnoreCase(
                request.getActionType())) {

            if (request.getBorrowDuration() == null ||
                    request.getBorrowDuration() <= 0) {
                return null;
            }

            LocalDate startDate = LocalDate.now();

            LocalDate dueDate =
                    startDate.plusDays(
                            request.getBorrowDuration()
                    );

            request.setBorrowStartDate(startDate);
            request.setDueDate(dueDate);
        }

        // =====================================================
        // SELL
        // =====================================================

        if ("Sell".equalsIgnoreCase(
                request.getActionType())) {

            if (book.getSellingPrice() == null ||
                    book.getSellingPrice()
                            .compareTo(BigDecimal.ZERO) <= 0) {
                return null;
            }

            request.setSellingPrice(book.getSellingPrice());
            request.setPaymentStatus("Pending");
        }

        book.setStatus("Reserved");
        book.setBorrowedBy(request.getRequesterEmail());
        bookRepository.save(book);

        request.setStatus("Approved");
        request.setApprovedDate(LocalDateTime.now());

        BorrowRequest savedRequest =
                requestRepository.save(request);

        // Email to requester
        emailService.sendApprovalEmail(savedRequest);

        // Notification to requester
        String approvalMessage;

        if ("Sell".equalsIgnoreCase(
                savedRequest.getActionType())) {

            approvalMessage =
                    "Your purchase request for \""
                            + savedRequest.getBookTitle()
                            + "\" has been approved. "
                            + "Payment of ₹"
                            + savedRequest.getSellingPrice()
                            + " is required.";

        } else if ("Borrow".equalsIgnoreCase(
                savedRequest.getActionType())) {

            approvalMessage =
                    "Your borrow request for \""
                            + savedRequest.getBookTitle()
                            + "\" has been approved. "
                            + "Return the book by "
                            + savedRequest.getDueDate()
                            + ".";

        } else {

            approvalMessage =
                    "Your "
                            + savedRequest.getActionType()
                            + " request for \""
                            + savedRequest.getBookTitle()
                            + "\" has been approved.";
        }

        notificationService.createNotification(
                savedRequest.getRequesterEmail(),
                approvalMessage,
                "APPROVED",
                savedRequest.getId()
        );

        // Sell payment notification
        if ("Sell".equalsIgnoreCase(
                savedRequest.getActionType())) {

            notificationService.createNotification(
                    savedRequest.getRequesterEmail(),

                    "Payment required for \""
                            + savedRequest.getBookTitle()
                            + "\". Amount: ₹"
                            + savedRequest.getSellingPrice(),

                    "PAYMENT_REQUIRED"
                    ,
                    savedRequest.getId()
            );
        }

        // Reject only competing pending requests for this book.
        List<BorrowRequest> competingRequests =
                requestRepository
                        .findByOwnerEmailAndBookIdAndStatusIgnoreCase(
                                request.getOwnerEmail(),
                                request.getBookId(),
                                BorrowRequest.STATUS_PENDING
                        );

        if (!competingRequests.isEmpty()) {
            for (BorrowRequest otherRequest : competingRequests) {
                otherRequest.setStatus(BorrowRequest.STATUS_REJECTED);
            }

            requestRepository.saveAll(competingRequests);

            for (BorrowRequest rejectedRequest : competingRequests) {
                emailService.sendRejectionEmail(rejectedRequest);

                notificationService.createNotification(
                        rejectedRequest.getRequesterEmail(),

                        "Your request for \""
                                + rejectedRequest.getBookTitle()
                                + "\" was rejected because "
                                + "the book was approved for another requester.",

                        "REJECTED"
                        ,
                        rejectedRequest.getId()
                );
            }
        }

        return savedRequest;
    }

    // =========================================================
    // REJECT REQUEST
    // =========================================================

    public BorrowRequest rejectRequest(
            Long requestId) {

        BorrowRequest request =
                requestRepository.findById(requestId)
                        .orElse(null);

        if (request == null) {
            return null;
        }

        if (!BorrowRequest.STATUS_PENDING.equalsIgnoreCase(
                request.getStatus())
                && !BorrowRequest.STATUS_APPROVED.equalsIgnoreCase(
                        request.getStatus())) {
            return request;
        }

        boolean wasApproved = BorrowRequest.STATUS_APPROVED.equalsIgnoreCase(
                request.getStatus());

        request.setStatus(BorrowRequest.STATUS_REJECTED);

        if (wasApproved) {
            Book book = bookRepository.findById(request.getBookId())
                    .orElse(null);

            if (book != null) {
                book.setStatus("Available");
                book.setBorrowedBy(null);
                bookRepository.save(book);
            }
        }

        BorrowRequest savedRequest =
                requestRepository.save(request);

        emailService.sendRejectionEmail(savedRequest);

        notificationService.createNotification(
                savedRequest.getRequesterEmail(),

                "Your "
                        + savedRequest.getActionType()
                        + " request for \""
                        + savedRequest.getBookTitle()
                        + "\" has been rejected by the owner.",

                "REJECTED"
                ,
                savedRequest.getId()
        );

        return savedRequest;
    }

    // =========================================================
    // CANCEL REQUEST (Requester)
    // Allowed only before the owner ships the book:
    // Pending -> Cancelled
    // Approved -> Cancelled
    // Not allowed once Shipped / Delivered / Rejected / Cancelled
    // =========================================================

    public BorrowRequest cancelRequest(
            Long requestId) {

        BorrowRequest request =
                requestRepository.findById(requestId)
                        .orElse(null);

        if (request == null) {
            return null;
        }

        if (!"Pending".equalsIgnoreCase(request.getStatus())
                && !"Approved".equalsIgnoreCase(request.getStatus())) {
            return null;
        }

        request.setStatus("Cancelled");

        BorrowRequest savedRequest =
                requestRepository.save(request);

        Book book =
                bookRepository.findById(
                        request.getBookId()
                ).orElse(null);

        if (book != null) {

            book.setStatus("Available");
            book.setBorrowedBy(null);

            bookRepository.save(book);
        }

        notificationService.createNotification(
                request.getRequesterEmail(),

                "Your request for \""
                        + request.getBookTitle()
                        + "\" has been cancelled.",

                "REQUEST_CANCELLED"
                ,
                savedRequest.getId()
        );

        return savedRequest;
    }

    // =========================================================
    // DELETE REQUEST
    // Pending / Approved ONLY
    // =========================================================

    public boolean deleteRequest(
            Long requestId) {

        BorrowRequest request =
                requestRepository.findById(requestId)
                        .orElse(null);

        if (request == null) {
            return false;
        }

        String status = request.getStatus();

        if (!"Pending".equalsIgnoreCase(status)
                && !"Approved".equalsIgnoreCase(status)) {
            return false;
        }

        if ("Approved".equalsIgnoreCase(status)) {

            Book book =
                    bookRepository.findById(
                            request.getBookId()
                    ).orElse(null);

            if (book != null) {

                book.setStatus("Available");
                book.setBorrowedBy(null);

                bookRepository.save(book);
            }
        }

        requestRepository.delete(request);

        return true;
    }

    // =========================================================
    // SHIP BOOK
    // =========================================================

    public BorrowRequest shipBook(
            Long requestId) {

        BorrowRequest request =
                requestRepository.findById(requestId)
                        .orElse(null);

        if (request == null) {
            return null;
        }

        if (!BorrowRequest.STATUS_APPROVED.equalsIgnoreCase(
                request.getStatus())) {
            return null;
        }

        if ("Sell".equalsIgnoreCase(
                request.getActionType())) {

            if (!"Paid".equalsIgnoreCase(
                    request.getPaymentStatus())) {
                return null;
            }
        }

        request.setStatus(BorrowRequest.STATUS_SHIPPED);
        request.setShippedDate(LocalDateTime.now());

        BorrowRequest savedRequest =
                requestRepository.save(request);

        emailService.sendShippedEmail(savedRequest);

        notificationService.createNotification(
                savedRequest.getRequesterEmail(),

                "Your book \""
                        + savedRequest.getBookTitle()
                        + "\" has been shipped. "
                        + "Please confirm when you receive it.",

                "SHIPPED"
                ,
                savedRequest.getId()
        );

        return savedRequest;
    }

    // =========================================================
    // REQUESTER CONFIRMS RECEIVED
    // Shipped → Delivered
    // =========================================================

    public BorrowRequest confirmReceived(
            Long requestId) {

        BorrowRequest request =
                requestRepository.findById(requestId)
                        .orElse(null);

        if (request == null) {
            return null;
        }

        if (!BorrowRequest.STATUS_SHIPPED.equalsIgnoreCase(
                request.getStatus())) {
            return null;
        }

        request.setStatus(BorrowRequest.STATUS_DELIVERED);
        request.setReceivedDate(LocalDateTime.now());

        return completeDeliveredRequest(request);
    }

    private BorrowRequest completeDeliveredRequest(BorrowRequest request) {
        Book completedBook =
                bookRepository.findById(request.getBookId())
                        .orElse(null);

        if (completedBook != null) {
            completedBook.setStatus("Completed");
            completedBook.setBorrowedBy(request.getRequesterEmail());
            bookRepository.save(completedBook);
        }

        BorrowRequest savedRequest =
                requestRepository.save(request);

        emailService.sendDeliveredEmailToRequester(
                savedRequest
        );

        emailService.sendDeliveredEmailToOwner(
                savedRequest
        );

        notificationService.createNotification(
                savedRequest.getRequesterEmail(),

                "Your book \""
                        + savedRequest.getBookTitle()
                        + "\" has been successfully delivered.",

                "DELIVERED"
                ,
                savedRequest.getId()
        );

        notificationService.createNotification(
                savedRequest.getOwnerEmail(),

                "The request for \""
                        + savedRequest.getBookTitle()
                        + "\" has been completed successfully.",

                "DELIVERED"
                ,
                savedRequest.getId()
        );

        return savedRequest;
    }

    // =========================================================
    // VALID ACTION
    // =========================================================

    private boolean isValidAction(
            String actionType) {

        if (actionType == null) {
            return false;
        }

        switch (actionType.toLowerCase()) {

            case "donate":
            case "exchange":
            case "borrow":
            case "sell":
            case "free":
            case "buy":
                return true;

            default:
                return false;
        }
    }

    // =========================================================
    // FINAL BOOK STATUS
    // =========================================================

    private String getFinalStatus(
            String actionType) {

        if (actionType == null) {
            return "Unavailable";
        }

        switch (actionType.toLowerCase()) {

            case "borrow":
                return "Borrowed";

            case "exchange":
                return "Exchanged";

            case "donate":
                return "Donated";

            default:
                return "Unavailable";
        }
    }
}