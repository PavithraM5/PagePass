package com.pagepass.service;

import com.pagepass.entity.Book;
import com.pagepass.entity.DonationRequest;
import com.pagepass.repository.BookRepository;
import com.pagepass.repository.DonationRequestRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DonationRequestService {

    private final DonationRequestRepository donationRequestRepository;

    private final BookRepository bookRepository;

    public DonationRequestService(
            DonationRequestRepository donationRequestRepository,
            BookRepository bookRepository) {

        this.donationRequestRepository =
                donationRequestRepository;

        this.bookRepository =
                bookRepository;
    }


    // Create donation request

    public DonationRequest createRequest(
            Long bookId,
            String requesterEmail) {

        Book book =
                bookRepository
                        .findById(bookId)
                        .orElse(null);

        if (book == null) {
            return null;
        }


        // Check whether this is a donation book

        if (!"Donate".equalsIgnoreCase(
                book.getActionType())) {

            return null;
        }


        // Check availability

        if (!"Available".equalsIgnoreCase(
                book.getStatus())) {

            return null;
        }


        // Prevent owner from requesting own book

        if (book.getOwnerEmail() != null &&
            book.getOwnerEmail()
                .equalsIgnoreCase(requesterEmail)) {

            return null;
        }


        DonationRequest request =
                new DonationRequest(
                        book.getId(),
                        book.getTitle(),
                        book.getOwnerEmail(),
                        requesterEmail
                );


        return donationRequestRepository.save(request);
    }


    // Get requests received by donor

    public List<DonationRequest> getDonorRequests(
            String donorEmail) {

        return donationRequestRepository
                .findByDonorEmail(donorEmail);
    }


    // Get requests made by requester

    public List<DonationRequest> getMyRequests(
            String requesterEmail) {

        return donationRequestRepository
                .findByRequesterEmail(requesterEmail);
    }


    // Accept donation request

    public DonationRequest acceptRequest(
            Long requestId) {

        DonationRequest request =
                donationRequestRepository
                        .findById(requestId)
                        .orElse(null);

        if (request == null) {
            return null;
        }


        Book book =
                bookRepository
                        .findById(request.getBookId())
                        .orElse(null);

        if (book == null) {
            return null;
        }


        if (!"Pending".equalsIgnoreCase(
                request.getStatus())) {

            return null;
        }


        if (!"Available".equalsIgnoreCase(
                book.getStatus())) {

            return null;
        }


        // Mark request as accepted

        request.setStatus("Accepted");


        // Mark book as donated

        book.setStatus("Donated");

        bookRepository.save(book);


        return donationRequestRepository
                .save(request);
    }


    // Reject donation request

    public DonationRequest rejectRequest(
            Long requestId) {

        DonationRequest request =
                donationRequestRepository
                        .findById(requestId)
                        .orElse(null);

        if (request == null) {
            return null;
        }


        if (!"Pending".equalsIgnoreCase(
                request.getStatus())) {

            return null;
        }


        request.setStatus("Rejected");


        return donationRequestRepository
                .save(request);
    }
}