package com.pagepass.service;

import com.pagepass.entity.BorrowRequest;
import com.pagepass.entity.User;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    private final JavaMailSender mailSender;

    @Value("${spring.mail.username}")
    private String mailUsername;

    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    public void sendPasswordEmail(User user) {

        SimpleMailMessage message = new SimpleMailMessage();

        message.setTo(user.getEmail());
        message.setFrom(mailUsername);
        message.setSubject("PagePass | Password Recovery");
        message.setText(
                "Hello " + user.getName() + ",\n\n"
                + "Here are your PagePass account details:\n\n"
                + "Username: " + user.getName() + "\n"
                + "Password: " + user.getPassword() + "\n\n"
                + "Regards,\n"
                + "PagePass Team"
        );

        try {
            mailSender.send(message);
        } catch (MailException e) {
            System.err.println("Password email sending failed: " + e.getMessage());
            throw e;
        }
    }

    // =====================================================
    // NEW BOOK REQUEST EMAIL
    // =====================================================

    public void sendNewRequestEmail(BorrowRequest request) {

        SimpleMailMessage message = new SimpleMailMessage();

        message.setTo(request.getOwnerEmail());
        message.setFrom(mailUsername);
        message.setSubject("PagePass | New Book Request Received");

        message.setText(
                "Hello,\n\n"
                + "You have received a new book request through PagePass.\n\n"
                + "Request Details\n"
                + "-------------------------\n"
                + "Book: " + request.getBookTitle() + "\n"
                + "Requester: " + request.getRequesterName() + "\n"
                + "Action: " + request.getActionType() + "\n"
                + "Request Status: Pending\n"
                + "-------------------------\n\n"
                + "Please log in to your PagePass account to review this request.\n\n"
                + "Thank you for using PagePass.\n\n"
                + "Regards,\n"
                + "PagePass Team"
        );

        sendEmail(message);
    }

    // =====================================================
    // APPROVAL EMAIL
    // =====================================================

    @Async
    public void sendApprovalEmail(BorrowRequest request) {

        SimpleMailMessage message = new SimpleMailMessage();

        message.setTo(request.getRequesterEmail());
        message.setFrom(mailUsername);
        message.setSubject("PagePass | Your Book Request Has Been Approved");

        message.setText(
                "Hello " + request.getRequesterName() + ",\n\n"
                + "Your request for the following book has been approved by the owner.\n\n"
                + "Book: " + request.getBookTitle() + "\n"
                + "Action: " + request.getActionType() + "\n"
                + "Status: Approved\n\n"
                + "Please log in to your PagePass account to view the next steps.\n\n"
                + "Regards,\n"
                + "PagePass Team"
        );

        sendEmail(message);
    }

    // =====================================================
    // REJECTION EMAIL
    // =====================================================

    @Async
    public void sendRejectionEmail(BorrowRequest request) {

        SimpleMailMessage message = new SimpleMailMessage();

        message.setTo(request.getRequesterEmail());
        message.setFrom(mailUsername);
        message.setSubject("PagePass | Update on Your Book Request");

        message.setText(
                "Hello " + request.getRequesterName() + ",\n\n"
                + "Thank you for using PagePass.\n\n"
                + "Your request for the book below was not approved by the owner.\n\n"
                + "Book: " + request.getBookTitle() + "\n"
                + "Status: Rejected\n\n"
                + "You can explore other available books on PagePass.\n\n"
                + "Regards,\n"
                + "PagePass Team"
        );

        sendEmail(message);
    }

    // =====================================================
    // SHIPPED EMAIL
    // =====================================================

    @Async
    public void sendShippedEmail(BorrowRequest request) {

        SimpleMailMessage message = new SimpleMailMessage();

        message.setTo(request.getRequesterEmail());
        message.setFrom(mailUsername);
        message.setSubject("PagePass | Your Book Has Been Shipped");

        message.setText(
                "Hello " + request.getRequesterName() + ",\n\n"
                + "The owner has marked your requested book as shipped.\n\n"
                + "Book: " + request.getBookTitle() + "\n"
                + "Status: Shipped\n\n"
                + "Once you receive the book, please log in to PagePass "
                + "and confirm receipt.\n\n"
                + "Regards,\n"
                + "PagePass Team"
        );

        sendEmail(message);
    }

    // =====================================================
    // DELIVERY CONFIRMED EMAIL TO REQUESTER
    // =====================================================

    public void sendDeliveredEmailToRequester(BorrowRequest request) {

        SimpleMailMessage message = new SimpleMailMessage();

        message.setTo(request.getRequesterEmail());
        message.setFrom(mailUsername);
        message.setSubject("PagePass | Delivery Confirmed");

        message.setText(
                "Hello " + request.getRequesterName() + ",\n\n"
                + "You have confirmed receiving your book.\n\n"
                + "Book: " + request.getBookTitle() + "\n"
                + "Status: Delivered\n\n"
                + "Thank you for using PagePass.\n\n"
                + "Regards,\n"
                + "PagePass Team"
        );

        sendEmail(message);
    }

    // =====================================================
    // DELIVERY CONFIRMED EMAIL TO OWNER
    // =====================================================

    public void sendDeliveredEmailToOwner(BorrowRequest request) {

        SimpleMailMessage message = new SimpleMailMessage();

        message.setTo(request.getOwnerEmail());
        message.setFrom(mailUsername);
        message.setSubject("PagePass | Book Delivery Completed");

        message.setText(
                "Hello,\n\n"
                + "The delivery process for your book has been completed successfully.\n\n"
                + "Book: " + request.getBookTitle() + "\n"
                + "Requester: " + request.getRequesterName() + "\n"
                + "Status: Delivered\n\n"
                + "Thank you for using PagePass.\n\n"
                + "Regards,\n"
                + "PagePass Team"
        );

        sendEmail(message);
    }

    // =====================================================
    // COMMON EMAIL SENDING METHOD
    // =====================================================

    private void sendEmail(SimpleMailMessage message) {

        try {
            mailSender.send(message);

            System.out.println(
                    "Email sent successfully to: "
                            + message.getTo()[0]
            );

        } catch (Exception e) {

            System.err.println(
                    "Email sending failed: "
                            + e.getMessage()
            );
        }
    }
}