package com.pagepass.service;

import com.pagepass.dto.CreateOrderRequest;
import com.pagepass.dto.PaymentOrderResponse;
import com.pagepass.dto.PaymentVerificationRequest;
import com.pagepass.entity.BorrowRequest;
import com.pagepass.repository.BorrowRequestRepository;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.LocalDateTime;

@Service
public class RazorpayPaymentService {

    private static final String CURRENCY = "INR";
    private static final String PAID = "Paid";

    private final BorrowRequestRepository requestRepository;
    private final NotificationService notificationService;
    private final String keyId;
    private final String keySecret;

    public RazorpayPaymentService(
            BorrowRequestRepository requestRepository,
            NotificationService notificationService,
            @Value("${razorpay.key-id}") String keyId,
            @Value("${razorpay.key-secret}") String keySecret) {
        this.requestRepository = requestRepository;
        this.notificationService = notificationService;
        this.keyId = keyId;
        this.keySecret = keySecret;
        System.out.println("RAZORPAY KEY ID LOADED: " + !keyId.isBlank());
        System.out.println("RAZORPAY SECRET LOADED: " + !keySecret.isBlank());
    }

    public String getKeyId() {
        return keyId;
    }

    public PaymentOrderResponse createOrder(CreateOrderRequest orderRequest) {
        if (isBlank(keyId) || isBlank(keySecret)) {
            throw new ResponseStatusException(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Razorpay credentials are not configured on the server.");
        }
        if (orderRequest == null || orderRequest.requestId() == null
                || orderRequest.amount() == null) {
            throw badRequest("Request ID and amount are required.");
        }

        BorrowRequest request = findSellRequest(orderRequest.requestId());
        if (!BorrowRequest.STATUS_APPROVED.equalsIgnoreCase(request.getStatus())) {
            throw badRequest("Payment is available only for approved requests.");
        }

        if (PAID.equalsIgnoreCase(request.getPaymentStatus())) {
            throw badRequest("This request has already been paid.");
        }

        BigDecimal expectedAmount = normalise(request.getSellingPrice());
        BigDecimal suppliedAmount = normalise(orderRequest.amount());
        if (expectedAmount == null || suppliedAmount == null
                || expectedAmount.compareTo(suppliedAmount) != 0) {
            throw badRequest("The payment amount does not match the request price.");
        }

        long amountInPaise;
        try {
            amountInPaise = expectedAmount.movePointRight(2)
                    .setScale(0, RoundingMode.UNNECESSARY).longValueExact();
        } catch (ArithmeticException exception) {
            throw badRequest("Invalid payment amount.");
        }
        if (amountInPaise < 100) {
            throw badRequest("Payment amount must be at least ₹1.00.");
        }

        try {
            RazorpayClient client = new RazorpayClient(keyId, keySecret);
            JSONObject options = new JSONObject();
            options.put("amount", amountInPaise);
            options.put("currency", CURRENCY);
            options.put("receipt", "pagepass_request_" + request.getId());
            Order order = client.orders.create(options);

            request.setRazorpayOrderId(order.get("id"));
            requestRepository.save(request);
            return new PaymentOrderResponse(order.get("id"), amountInPaise, CURRENCY);
        } catch (Exception exception) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_GATEWAY,
                    "Unable to create the Razorpay order.",
                    exception);
        }
    }

    public BorrowRequest verifyPayment(PaymentVerificationRequest verification) {
        if (verification == null || verification.requestId() == null
                || isBlank(verification.razorpayOrderId())
                || isBlank(verification.razorpayPaymentId())
                || isBlank(verification.razorpaySignature())) {
            throw badRequest("All payment verification fields are required.");
        }

        BorrowRequest request = findSellRequest(verification.requestId());
        if (!verification.razorpayOrderId().equals(request.getRazorpayOrderId())) {
            throw badRequest("The Razorpay order does not match this request.");
        }
        if (PAID.equalsIgnoreCase(request.getPaymentStatus())) {
            return request;
        }

        String payload = verification.razorpayOrderId()
                + "|" + verification.razorpayPaymentId();
        if (!isValidSignature(payload, verification.razorpaySignature())) {
            throw badRequest("Payment verification failed. The signature is invalid.");
        }

        request.setPaymentTransactionId(verification.razorpayPaymentId());
        request.setPaymentStatus(PAID);
        request.setPaymentDate(LocalDateTime.now());
        BorrowRequest savedRequest = requestRepository.save(request);

        notificationService.createNotification(
                savedRequest.getRequesterEmail(),
                "Payment received for \"" + savedRequest.getBookTitle()
                        + "\". The book is ready for shipping.",
                "PAYMENT_SUCCESS",
                savedRequest.getId());
        notificationService.createNotification(
                savedRequest.getOwnerEmail(),
                "Payment received for \"" + savedRequest.getBookTitle()
                        + "\". You can now mark the book as shipped.",
                "PAYMENT_SUCCESS",
                savedRequest.getId());

        return savedRequest;
    }

    private BorrowRequest findSellRequest(Long requestId) {
        BorrowRequest request = requestRepository.findById(requestId).orElse(null);
        if (request == null || !"Sell".equalsIgnoreCase(request.getActionType())) {
            throw badRequest("Only paid Sell requests can use Razorpay payment.");
        }
        return request;
    }

    private boolean isValidSignature(String payload, String signature) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(
                    keySecret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
            byte[] expected = mac.doFinal(payload.getBytes(StandardCharsets.UTF_8));
            byte[] actual = hexToBytes(signature);
            return MessageDigest.isEqual(expected, actual);
        } catch (Exception exception) {
            return false;
        }
    }

    private static byte[] hexToBytes(String value) {
        if ((value.length() & 1) != 0) {
            return new byte[0];
        }
        byte[] result = new byte[value.length() / 2];
        for (int index = 0; index < value.length(); index += 2) {
            int high = Character.digit(value.charAt(index), 16);
            int low = Character.digit(value.charAt(index + 1), 16);
            if (high < 0 || low < 0) {
                return new byte[0];
            }
            result[index / 2] = (byte) ((high << 4) + low);
        }
        return result;
    }

    private static BigDecimal normalise(BigDecimal amount) {
        return amount == null ? null : amount.setScale(2, RoundingMode.HALF_UP);
    }

    private static boolean isBlank(String value) {
        return value == null || value.isBlank();
    }

    private static ResponseStatusException badRequest(String message) {
        return new ResponseStatusException(HttpStatus.BAD_REQUEST, message);
    }
}
