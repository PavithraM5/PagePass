package com.pagepass.repository;

import com.pagepass.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BookRepository extends JpaRepository<Book, Long> {

    List<Book> findByBorrowedBy(String borrowedBy);

    List<Book> findByActionType(String actionType);

    List<Book> findByOwnerEmail(String ownerEmail);

    List<Book> findByStatusIgnoreCase(String status);

    List<Book> findByActionTypeAndStatusIgnoreCase(
            String actionType,
            String status
    );
}