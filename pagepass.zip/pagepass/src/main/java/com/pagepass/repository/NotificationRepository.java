package com.pagepass.repository;

import com.pagepass.entity.Notification;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NotificationRepository extends JpaRepository<Notification, Long> {

    List<Notification> findByRecipientEmailOrderByIdDesc(String recipientEmail);

    long countByRecipientEmailAndIsReadFalse(String recipientEmail);
}