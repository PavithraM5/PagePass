package com.pagepass.repository;

import com.pagepass.entity.DonationRequest;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DonationRequestRepository
        extends JpaRepository<DonationRequest, Long> {

    List<DonationRequest> findByDonorEmail(String donorEmail);

    List<DonationRequest> findByRequesterEmail(String requesterEmail);

    List<DonationRequest> findByBookId(Long bookId);
}
