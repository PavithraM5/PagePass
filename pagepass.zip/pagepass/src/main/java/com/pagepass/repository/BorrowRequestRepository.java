package com.pagepass.repository;

import com.pagepass.entity.BorrowRequest;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BorrowRequestRepository
        extends JpaRepository<BorrowRequest, Long> {

    // =========================================================
    // OWNER REQUESTS
    // =========================================================

    List<BorrowRequest> findByOwnerEmail(String ownerEmail);

    List<BorrowRequest> findByOwnerEmailAndBookIdAndStatusIgnoreCase(
            String ownerEmail,
            Long bookId,
            String status
    );

    // =========================================================
    // REQUESTER REQUESTS
    // =========================================================

    List<BorrowRequest> findByRequesterEmail(String requesterEmail);

    // =========================================================
    // BOOK REQUESTS
    // =========================================================

    List<BorrowRequest> findByBookId(Long bookId);

    // =========================================================
    // REQUESTER HISTORY
    // =========================================================

    List<BorrowRequest> findByRequesterEmailAndStatus(
            String requesterEmail,
            String status
    );

    List<BorrowRequest> findByRequesterEmailAndStatusIn(
            String requesterEmail,
            List<String> statuses
    );

    // =========================================================
    // OWNER HISTORY
    // =========================================================

    List<BorrowRequest> findByOwnerEmailAndStatus(
            String ownerEmail,
            String status
    );

    List<BorrowRequest> findByOwnerEmailAndStatusIn(
            String ownerEmail,
            List<String> statuses
    );
}