package com.pagepass.controller;

import com.pagepass.entity.Notification;
import com.pagepass.service.NotificationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notifications")
@CrossOrigin
public class NotificationController {

    private final NotificationService notificationService;

    public NotificationController(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @GetMapping
    public ResponseEntity<List<Notification>> getNotifications(
            @RequestParam String email) {

        return ResponseEntity.ok(
                notificationService.getNotifications(email)
        );
    }

    @GetMapping("/unread-count")
    public ResponseEntity<Long> getUnreadCount(
            @RequestParam String email) {

        return ResponseEntity.ok(
                notificationService.getUnreadCount(email)
        );
    }

    @PutMapping("/{id}/read")
    public ResponseEntity<?> markAsRead(
            @PathVariable("id") Long id) {

        Notification notification =
                notificationService.markAsRead(id);

        if (notification == null) {
            return ResponseEntity.badRequest()
                    .body("Notification not found.");
        }

        return ResponseEntity.ok(notification);
    }

    @PutMapping("/read-all")
    public ResponseEntity<?> markAllAsRead(
            @RequestParam String email) {

        notificationService.markAllAsRead(email);

        return ResponseEntity.ok(
                "All notifications marked as read."
        );
    }
}