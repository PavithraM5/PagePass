package com.pagepass.controller;

import com.pagepass.entity.User;
import com.pagepass.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
@CrossOrigin
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody User user) {

        try {

            User savedUser = userService.registerUser(user);

            return ResponseEntity.ok(savedUser);

        } catch (Exception e) {

            return ResponseEntity.badRequest()
                    .body("Registration failed.");
        }
    }


    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User user) {

        User loggedInUser =
                userService.loginUser(
                        user.getEmail(),
                        user.getPassword()
                );

        if (loggedInUser == null) {

            return ResponseEntity
                    .status(401)
                    .body("Invalid email or password.");
        }

        return ResponseEntity.ok(loggedInUser);
    }

    @PostMapping("/forgot-password")
    public ResponseEntity<String> forgotPassword(@RequestBody User user) {

        try {
            boolean sent = userService.sendPasswordEmail(user.getEmail());

            if (!sent) {
                return ResponseEntity
                        .notFound()
                        .build();
            }

            return ResponseEntity.ok("Password sent to your registered email address.");
        } catch (MailException e) {
            return ResponseEntity
                    .internalServerError()
                    .body("Unable to send your password email. Please try again later.");
        }
    }


    @GetMapping("/{email}")
    public ResponseEntity<?> getUser(
            @PathVariable("email") String email) {

        User user = userService.getUserByEmail(email);

        if (user == null) {

            return ResponseEntity
                    .notFound()
                    .build();
        }

        return ResponseEntity.ok(user);
    }


    @PutMapping("/update")
    public ResponseEntity<?> updateProfile(
            @RequestBody User user) {

        User updatedUser =
                userService.updateUser(user);

        if (updatedUser == null) {

            return ResponseEntity
                    .notFound()
                    .build();
        }

        return ResponseEntity.ok(updatedUser);
    }

}