package com.pagepass.controller;

import com.pagepass.entity.Book;
import com.pagepass.service.BookService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/books")
@CrossOrigin
public class BookController {

    private final BookService bookService;

    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    // =========================================================
    // ADD BOOK
    // =========================================================
    @PostMapping
    public ResponseEntity<Book> addBook(
            @RequestBody Book book) {

        return ResponseEntity.ok(
                bookService.addBook(book)
        );
    }

    // =========================================================
    // GET ALL AVAILABLE BOOKS
    // =========================================================
    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {

        return ResponseEntity.ok(
                bookService.getAllBooks()
        );
    }

    // =========================================================
    // GET BOOKS BY ACTION
    // =========================================================
    @GetMapping("/action/{actionType}")
    public ResponseEntity<List<Book>> getBooksByAction(
            @PathVariable String actionType) {

        return ResponseEntity.ok(
                bookService.getBooksByAction(actionType)
        );
    }

    // =========================================================
    // GET MY LISTED BOOKS
    // =========================================================
    @GetMapping("/my-listed-books")
    public ResponseEntity<List<Book>> getMyListedBooks(
            @RequestParam("email") String email) {

        return ResponseEntity.ok(
                bookService.getBooksByOwner(email)
        );
    }

    // =========================================================
    // GET MY BOOKS
    // =========================================================
    @GetMapping("/my-books")
    public ResponseEntity<List<Book>> getMyBooks(
            @RequestParam String email) {

        return ResponseEntity.ok(
                bookService.getMyBooks(email)
        );
    }

    // =========================================================
    // GET BOOK BY ID
    // =========================================================
    @GetMapping("/{id}")
    public ResponseEntity<?> getBookById(
            @PathVariable("id") Long id) {

        Book book = bookService.getBookById(id);

        if (book == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(book);
    }

    // =========================================================
    // BORROW BOOK
    // =========================================================
    @PutMapping("/{id}/borrow")
    public ResponseEntity<?> borrowBook(
            @PathVariable("id") Long id,
            @RequestParam String email) {

        Book book = bookService.borrowBook(id, email);

        if (book == null) {

            return ResponseEntity.badRequest()
                    .body("Book is not available for borrowing.");
        }

        return ResponseEntity.ok(book);
    }

    // =========================================================
    // MARK BOOK UNAVAILABLE
    // =========================================================
    @PutMapping("/{id}/unavailable")
    public ResponseEntity<?> markUnavailable(
            @PathVariable("id") Long id) {

        Book book = bookService.markUnavailable(id);

        if (book == null) {

            return ResponseEntity.badRequest()
                    .body("Book not found.");
        }

        return ResponseEntity.ok(book);
    }

    // =========================================================
    // DELETE BOOK
    // =========================================================
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteBook(
            @PathVariable("id") Long id) {

        boolean deleted = bookService.deleteBook(id);

        if (!deleted) {

            return ResponseEntity.badRequest()
                    .body(
                        "This book cannot be deleted because it is no longer available."
                    );
        }

        return ResponseEntity.ok(
                "Book deleted successfully."
        );
    }
}