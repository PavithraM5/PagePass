package com.pagepass.controller;

import com.pagepass.entity.BorrowRequest;
import com.pagepass.service.BorrowRequestService;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/requests")
@CrossOrigin
public class BorrowRequestController {

    private final BorrowRequestService requestService;

    public BorrowRequestController(
            BorrowRequestService requestService) {

        this.requestService = requestService;
    }

    // =========================================================
    // CREATE REQUEST
    // =========================================================

    @PostMapping
    public ResponseEntity<?> createRequest(

            @RequestParam("bookId") Long bookId,

            @RequestParam String email,

            @RequestParam String name,

            @RequestParam String phone,

            @RequestParam String address,

            @RequestParam String actionType,

            @RequestParam(required = false)
            String offeredBook,

            @RequestParam(required = false)
            Integer borrowDuration) {

        BorrowRequest request =
                requestService.createRequest(
                        bookId,
                        email,
                        name,
                        phone,
                        address,
                        actionType,
                        offeredBook,
                        borrowDuration
                );

        if (request == null) {

            return ResponseEntity
                    .badRequest()
                    .body(
                            "Unable to create request. " +
                            "Book may no longer be available " +
                            "or the request details are invalid."
                    );
        }

        return ResponseEntity.ok(request);
    }

    // =========================================================
    // OWNER REQUESTS
    // =========================================================

    @GetMapping("/owner")
    public ResponseEntity<List<BorrowRequest>> getOwnerRequests(
            @RequestParam("email") String email) {

        return ResponseEntity.ok(
                requestService.getOwnerRequests(email)
        );
    }

    // =========================================================
    // MY REQUESTS
    // =========================================================

    @GetMapping("/my")
    public ResponseEntity<List<BorrowRequest>> getMyRequests(
            @RequestParam("email") String email) {

        return ResponseEntity.ok(
                requestService.getMyRequests(email)
        );
    }

    // =========================================================
    // APPROVE REQUEST
    // =========================================================

    @PutMapping("/{id}/approve")
    public ResponseEntity<?> approveRequest(
            @PathVariable("id") Long id) {

        BorrowRequest request =
                requestService.approveRequest(id);

        if (request == null) {

            return ResponseEntity
                    .badRequest()
                    .body(
                            "Unable to approve request."
                    );
        }

        return ResponseEntity.ok(request);
    }

    // =========================================================
    // REJECT REQUEST
    // =========================================================

    @PutMapping("/{id}/reject")
    public ResponseEntity<?> rejectRequest(
            @PathVariable("id") Long id) {

        BorrowRequest request =
                requestService.rejectRequest(id);

        if (request == null) {

            return ResponseEntity
                    .badRequest()
                    .body(
                            "Unable to reject request."
                    );
        }

        return ResponseEntity.ok(request);
    }

    // =========================================================
    // CANCEL REQUEST
    // =========================================================

    @PutMapping("/{id}/cancel")
    public ResponseEntity<?> cancelRequest(
            @PathVariable("id") Long id) {

        BorrowRequest request =
                requestService.cancelRequest(id);

        if (request == null) {

            return ResponseEntity
                    .badRequest()
                    .body(
                            "Only pending or approved requests can be cancelled."
                    );
        }

        return ResponseEntity.ok(request);
    }

    // =========================================================
    // DELETE REQUEST
    // Pending / Approved ONLY
    // =========================================================

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteRequest(
            @PathVariable("id") Long id) {

        boolean deleted =
                requestService.deleteRequest(id);

        if (!deleted) {

            return ResponseEntity
                    .badRequest()
                    .body(
                            "This request cannot be deleted. " +
                            "Requests can only be deleted before shipping."
                    );
        }

        return ResponseEntity.ok(
                "Request deleted successfully."
        );
    }

    // =========================================================
    // SHIP BOOK
    // =========================================================

    @PutMapping("/{id}/ship")
    public ResponseEntity<?> shipBook(
            @PathVariable("id") Long id) {

        BorrowRequest request =
                requestService.shipBook(id);

        if (request == null) {

            return ResponseEntity
                    .badRequest()
                    .body(
                            "Book cannot be shipped yet. " +
                            "Check approval and payment status."
                    );
        }

        return ResponseEntity.ok(request);
    }

    // =========================================================
    // REQUESTER CONFIRMS RECEIVED
    // Shipped → Delivered
    // =========================================================

    @PutMapping("/{id}/confirm-received")
    public ResponseEntity<?> confirmReceived(
            @PathVariable("id") Long id) {

        BorrowRequest request =
                requestService.confirmReceived(id);

        if (request == null) {

            return ResponseEntity
                    .badRequest()
                    .body(
                            "Book cannot be confirmed as received. " +
                            "The request must be in Shipped status."
                    );
        }

        return ResponseEntity.ok(request);
    }

}