package com.pagepass.controller;

import com.pagepass.dto.CreateOrderRequest;
import com.pagepass.dto.PaymentOrderResponse;
import com.pagepass.dto.PaymentVerificationRequest;
import com.pagepass.entity.BorrowRequest;
import com.pagepass.service.RazorpayPaymentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class PaymentController {

    private final RazorpayPaymentService paymentService;

    public PaymentController(RazorpayPaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @GetMapping("/payment-config")
    public ResponseEntity<?> paymentConfig() {
        return ResponseEntity.ok(java.util.Map.of("keyId", paymentService.getKeyId()));
    }

    @PostMapping("/create-order")
    public ResponseEntity<PaymentOrderResponse> createOrder(
            @RequestBody CreateOrderRequest orderRequest) {
        return ResponseEntity.ok(paymentService.createOrder(orderRequest));
    }

    @PostMapping("/verify-payment")
    public ResponseEntity<BorrowRequest> verifyPayment(
            @RequestBody PaymentVerificationRequest verificationRequest) {
        return ResponseEntity.ok(paymentService.verifyPayment(verificationRequest));
    }
}
