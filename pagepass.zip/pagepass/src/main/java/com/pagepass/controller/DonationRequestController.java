package com.pagepass.controller;

import com.pagepass.entity.DonationRequest;
import com.pagepass.service.DonationRequestService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/donations")
@CrossOrigin
public class DonationRequestController {

    private final DonationRequestService donationRequestService;

    public DonationRequestController(
            DonationRequestService donationRequestService) {

        this.donationRequestService =
                donationRequestService;
    }


    // Request a donation

    @PostMapping("/request")
    public ResponseEntity<?> createRequest(
            @RequestParam("bookId") Long bookId,
            @RequestParam String email) {

        DonationRequest request =
                donationRequestService.createRequest(
                        bookId,
                        email
                );

        if (request == null) {

            return ResponseEntity
                    .badRequest()
                    .body(
                        "Book is not available for donation request."
                    );
        }

        return ResponseEntity.ok(request);
    }


    // Get donation requests received by donor

    @GetMapping("/donor")
    public ResponseEntity<List<DonationRequest>> getDonorRequests(
            @RequestParam String email) {

        return ResponseEntity.ok(
                donationRequestService
                        .getDonorRequests(email)
        );
    }


    // Get donation requests made by user

    @GetMapping("/my-requests")
    public ResponseEntity<List<DonationRequest>> getMyRequests(
            @RequestParam String email) {

        return ResponseEntity.ok(
                donationRequestService
                        .getMyRequests(email)
        );
    }


    // Accept donation request

    @PutMapping("/{id}/accept")
    public ResponseEntity<?> acceptRequest(
            @PathVariable("id") Long id) {

        DonationRequest request =
                donationRequestService
                        .acceptRequest(id);

        if (request == null) {

            return ResponseEntity
                    .badRequest()
                    .body(
                        "Unable to accept donation request."
                    );
        }

        return ResponseEntity.ok(request);
    }


    // Reject donation request

    @PutMapping("/{id}/reject")
    public ResponseEntity<?> rejectRequest(
            @PathVariable("id") Long id) {

        DonationRequest request =
                donationRequestService
                        .rejectRequest(id);

        if (request == null) {

            return ResponseEntity
                    .badRequest()
                    .body(
                        "Unable to reject donation request."
                    );
        }

        return ResponseEntity.ok(request);
    }
}
