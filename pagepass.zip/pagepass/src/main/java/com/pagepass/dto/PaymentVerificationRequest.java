package com.pagepass.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public record PaymentVerificationRequest(
        Long requestId,
        @JsonProperty("razorpay_order_id")
        String razorpayOrderId,
        @JsonProperty("razorpay_payment_id")
        String razorpayPaymentId,
        @JsonProperty("razorpay_signature")
        String razorpaySignature
) {
}
