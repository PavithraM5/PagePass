package com.pagepass.dto;

public record PaymentOrderResponse(
        String order_id,
        long amount,
        String currency
) {
}
