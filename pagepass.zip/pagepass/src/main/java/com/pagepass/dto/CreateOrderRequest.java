package com.pagepass.dto;

import java.math.BigDecimal;

public record CreateOrderRequest(
        Long requestId,
        BigDecimal amount
) {
}
