package com.pagepass;

import com.pagepass.repository.BookRepository;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableAsync
@EnableJpaRepositories(basePackageClasses = BookRepository.class)
public class PagepassApplication {

	public static void main(String[] args) {
		SpringApplication.run(PagepassApplication.class, args);
	}

}
